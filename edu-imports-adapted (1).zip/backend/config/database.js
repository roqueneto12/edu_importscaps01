const mongoose = require('mongoose');

const connectDB = async () => {
    try {
        // Lê a URI do MongoDB das variáveis de ambiente
        let mongoUri = process.env.MONGODB_URI;
        
        // Se a URI não estiver definida ou for localhost (para desenvolvimento local)
        if (!mongoUri || mongoUri.includes('localhost')) {
            console.log('⚠️  MongoDB local não disponível ou não configurado, usando fallback para desenvolvimento.');
            // Fallback para uma URI de desenvolvimento local, se necessário
            mongoUri = 'mongodb://127.0.0.1:27017/edu_imports_dev';
        }

        const conn = await mongoose.connect(mongoUri, {
            serverSelectionTimeoutMS: 5000, // Timeout mais curto para seleção do servidor
            socketTimeoutMS: 45000, // Timeout para operações de socket
        });

        console.log(`✅ MongoDB conectado: ${conn.connection.host}`);
        console.log(`📊 Banco de dados: ${conn.connection.name}`);
    } catch (error) {
        console.error('❌ Erro ao conectar com MongoDB:', error.message);
        console.log('💡 Para desenvolvimento, você pode:');
        console.log('   1. Instalar MongoDB localmente');
        console.log('   2. Usar MongoDB Atlas (nuvem)');
        console.log('   3. Usar Docker: docker run -d -p 27017:27017 mongo');
        
        // Em desenvolvimento, não sair do processo imediatamente para permitir depuração
        if (process.env.NODE_ENV !== 'production') {
            console.log('🔄 Continuando sem banco de dados para desenvolvimento (pode causar erros de funcionalidade)...');
            return;
        }
        
        process.exit(1); // Sair do processo em produção se a conexão falhar
    }
};

module.exports = connectDB;

