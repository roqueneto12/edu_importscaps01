# Edu_Imports Backend API

Backend API para a loja Edu_Imports desenvolvido em Node.js com Express.js e MongoDB.

## 🚀 Funcionalidades

- ✅ API RESTful completa para gerenciamento de produtos
- ✅ Sistema de produtos em destaque
- ✅ Ranking de produtos mais vendidos
- ✅ Busca e filtros avançados
- ✅ Paginação de resultados
- ✅ Validação de dados
- ✅ Tratamento de erros
- ✅ CORS configurado
- ✅ Estrutura escalável

## 📋 Pré-requisitos

- Node.js (versão 14 ou superior)
- MongoDB (local ou Atlas)
- npm ou yarn

## 🛠️ Instalação

1. **Clone o repositório ou extraia os arquivos**
```bash
cd edu-imports-backend
```

2. **Instale as dependências**
```bash
npm install
```

3. **Configure as variáveis de ambiente**
```bash
cp .env.example .env
# Edite o arquivo .env com suas configurações
```

4. **Configure o MongoDB**
   - **Opção 1 - MongoDB Local:**
     ```bash
     # Instale o MongoDB localmente
     # Ubuntu/Debian:
     sudo apt-get install mongodb
     
     # macOS:
     brew install mongodb-community
     ```
   
   - **Opção 2 - Docker:**
     ```bash
     docker run -d -p 27017:27017 --name mongodb mongo
     ```
   
   - **Opção 3 - MongoDB Atlas (Nuvem):**
     - Crie uma conta em https://cloud.mongodb.com
     - Crie um cluster gratuito
     - Obtenha a string de conexão
     - Atualize MONGODB_URI no arquivo .env

5. **Popule o banco com dados de exemplo (opcional)**
```bash
npm run seed
```

6. **Inicie o servidor**
```bash
# Desenvolvimento
npm run dev

# Produção
npm start
```

## 📚 Documentação da API

### Base URL
```
http://localhost:3000
```

### Endpoints Principais

#### 1. Informações da API
```http
GET /
```
**Resposta:**
```json
{
  "success": true,
  "message": "API Edu_Imports funcionando!",
  "version": "1.0.0",
  "endpoints": {
    "products": "/api/products",
    "featured": "/api/products/featured",
    "ranking": "/api/products/ranking"
  }
}
```

#### 2. Listar Produtos
```http
GET /api/products
```

**Parâmetros de Query:**
- `category` - Filtrar por categoria (perfumes, cosmeticos, acessorios, outros)
- `featured` - Filtrar produtos em destaque (true/false)
- `search` - Busca por texto no nome e descrição
- `sort` - Ordenação (-createdAt, price, -price, name, -sales)
- `page` - Página (padrão: 1)
- `limit` - Itens por página (padrão: 10)

**Exemplo:**
```http
GET /api/products?category=perfumes&featured=true&page=1&limit=5
```

**Resposta:**
```json
{
  "success": true,
  "count": 5,
  "total": 25,
  "page": 1,
  "pages": 5,
  "data": [
    {
      "_id": "...",
      "name": "Lattafa Asad Eau de Parfum",
      "description": "Esta fragrância exala uma aura de poder...",
      "price": 150,
      "oldPrice": 200,
      "image": "https://...",
      "category": "perfumes",
      "featured": true,
      "inStock": true,
      "stockQuantity": 25,
      "sales": 150,
      "rating": 4.8,
      "tags": ["masculino", "lattafa"],
      "createdAt": "2024-01-01T00:00:00.000Z",
      "updatedAt": "2024-01-01T00:00:00.000Z"
    }
  ]
}
```

#### 3. Obter Produto por ID
```http
GET /api/products/:id
```

#### 4. Produtos em Destaque
```http
GET /api/products/featured
```

#### 5. Ranking de Produtos
```http
GET /api/products/ranking
```

#### 6. Criar Produto (Admin)
```http
POST /api/products
Content-Type: application/json

{
  "name": "Nome do Produto",
  "description": "Descrição detalhada",
  "price": 100,
  "oldPrice": 120,
  "image": "https://exemplo.com/imagem.jpg",
  "category": "perfumes",
  "featured": false,
  "stockQuantity": 50,
  "tags": ["tag1", "tag2"]
}
```

#### 7. Atualizar Produto (Admin)
```http
PUT /api/products/:id
```

#### 8. Deletar Produto (Admin)
```http
DELETE /api/products/:id
```

## 🗂️ Estrutura do Projeto

```
edu-imports-backend/
├── config/
│   └── database.js          # Configuração do MongoDB
├── controllers/
│   └── productController.js # Lógica de negócio dos produtos
├── middleware/
│   └── errorHandler.js      # Tratamento de erros
├── models/
│   └── Product.js           # Modelo de dados do produto
├── routes/
│   └── products.js          # Rotas dos produtos
├── .env                     # Variáveis de ambiente
├── package.json             # Dependências e scripts
├── seedData.js              # Dados de exemplo
├── server.js                # Servidor principal
└── README.md                # Documentação
```

## 🔧 Scripts Disponíveis

```bash
npm start        # Inicia o servidor em produção
npm run dev      # Inicia o servidor em desenvolvimento (com nodemon)
npm run seed     # Popula o banco com dados de exemplo
npm test         # Executa os testes (a implementar)
```

## 🌍 Variáveis de Ambiente

```env
# Servidor
PORT=3000
NODE_ENV=development

# MongoDB
MONGODB_URI=mongodb://localhost:27017/edu_imports

# Segurança
JWT_SECRET=seu_jwt_secret_super_seguro
JWT_EXPIRE=7d

# Upload
MAX_FILE_SIZE=5242880
UPLOAD_PATH=./uploads

# CORS
CORS_ORIGIN=*
```

## 📊 Modelo de Dados

### Produto
```javascript
{
  name: String,           // Nome do produto (obrigatório)
  description: String,    // Descrição (obrigatório)
  price: Number,          // Preço atual (obrigatório)
  oldPrice: Number,       // Preço anterior (opcional)
  image: String,          // URL da imagem (obrigatório)
  category: String,       // Categoria (perfumes, cosmeticos, acessorios, outros)
  featured: Boolean,      // Produto em destaque (padrão: false)
  inStock: Boolean,       // Em estoque (padrão: true)
  stockQuantity: Number,  // Quantidade em estoque (padrão: 0)
  sales: Number,          // Número de vendas (padrão: 0)
  rating: Number,         // Avaliação 0-5 (padrão: 0)
  tags: [String],         // Tags do produto
  createdAt: Date,        // Data de criação
  updatedAt: Date         // Data de atualização
}
```

## 🚀 Deploy

### Heroku
```bash
# Instale o Heroku CLI
heroku create edu-imports-api
heroku config:set MONGODB_URI=sua_string_mongodb_atlas
heroku config:set JWT_SECRET=seu_jwt_secret
git push heroku main
```

### Vercel
```bash
npm install -g vercel
vercel
```

### Docker
```dockerfile
FROM node:16-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
EXPOSE 3000
CMD ["npm", "start"]
```

## 🔒 Segurança

- ✅ Validação de entrada de dados
- ✅ Sanitização de dados
- ✅ Tratamento de erros seguro
- ✅ CORS configurado
- ⏳ Autenticação JWT (a implementar)
- ⏳ Rate limiting (a implementar)
- ⏳ Helmet.js (a implementar)

## 🧪 Testes

Para testar a API manualmente:

```bash
# Testar se a API está funcionando
curl http://localhost:3000/

# Listar produtos
curl http://localhost:3000/api/products

# Produtos em destaque
curl http://localhost:3000/api/products/featured

# Ranking
curl http://localhost:3000/api/products/ranking

# Buscar produtos
curl "http://localhost:3000/api/products?search=perfume&category=perfumes"
```

## 🤝 Integração com Frontend

Para integrar com o frontend Vue.js fornecido:

1. **Configure CORS** - Já configurado para aceitar requisições de qualquer origem
2. **Use fetch ou axios** no frontend:

```javascript
// Exemplo de integração
const API_BASE = 'http://localhost:3000/api';

// Buscar produtos em destaque
async function getFeaturedProducts() {
  const response = await fetch(`${API_BASE}/products/featured`);
  const data = await response.json();
  return data.data;
}

// Buscar ranking
async function getProductRanking() {
  const response = await fetch(`${API_BASE}/products/ranking`);
  const data = await response.json();
  return data.data;
}
```

## 📝 Próximos Passos

- [ ] Implementar autenticação de usuários
- [ ] Sistema de carrinho de compras
- [ ] Processamento de pedidos
- [ ] Sistema de avaliações
- [ ] Upload de imagens
- [ ] Notificações por email
- [ ] Relatórios e analytics
- [ ] Testes automatizados

## 🐛 Solução de Problemas

### MongoDB não conecta
```bash
# Verificar se o MongoDB está rodando
sudo systemctl status mongod

# Iniciar MongoDB
sudo systemctl start mongod

# Ou usar Docker
docker run -d -p 27017:27017 mongo
```

### Erro de porta em uso
```bash
# Verificar processos na porta 3000
lsof -i :3000

# Matar processo
kill -9 PID
```

## 📞 Suporte

Para dúvidas ou problemas:
- Verifique os logs do servidor
- Consulte a documentação do MongoDB
- Verifique as variáveis de ambiente

---

**Desenvolvido para Edu_Imports** 🛍️

