const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const {
    registerWhatsappClick,
    getPendingOrders,
    getAllOrders,
    getOrderById,
    validateOrder,
    cancelOrder,
    generateExcelReport,
    generatePdfReport,
    getOrderStats
} = require('../controllers/orderController');

// Rotas públicas (requerem autenticação)
router.post('/whatsapp-click', protect, registerWhatsappClick);
router.get('/:id', protect, getOrderById);

// Rotas do administrador
router.get('/pending', protect, authorize('admin'), getPendingOrders);
router.get('/', protect, authorize('admin'), getAllOrders);
router.put('/:id/validate', protect, authorize('admin'), validateOrder);
router.put('/:id/cancel', protect, authorize('admin'), cancelOrder);
router.get('/report/excel', protect, authorize('admin'), generateExcelReport);
router.get('/report/pdf', protect, authorize('admin'), generatePdfReport);
router.get('/stats', protect, authorize('admin'), getOrderStats);

module.exports = router;
