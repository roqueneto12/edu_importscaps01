const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Proteger rotas - verificar se o usuário está autenticado
const protect = async (req, res, next) => {
    let token;

    // Verificar se o token existe no header Authorization
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
        token = req.headers.authorization.split(' ')[1];
    }
    // Verificar se o token existe nos cookies
    else if (req.cookies.token) {
        token = req.cookies.token;
    }

    // Verificar se o token existe
    if (!token) {
        return res.status(401).json({
            success: false,
            message: 'Não autorizado para acessar esta rota'
        });
    }

    try {
        // Verificar token
        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        // Buscar usuário pelo ID do token
        req.user = await User.findById(decoded.id);

        if (!req.user) {
            return res.status(401).json({
                success: false,
                message: 'Usuário não encontrado'
            });
        }

        next();
    } catch (error) {
        return res.status(401).json({
            success: false,
            message: 'Token inválido'
        });
    }
};

// Autorizar roles específicos
const authorize = (...roles) => {
    return (req, res, next) => {
        if (!roles.includes(req.user.role)) {
            return res.status(403).json({
                success: false,
                message: `Role ${req.user.role} não tem permissão para acessar esta rota`
            });
        }
        next();
    };
};

module.exports = { protect, authorize };

