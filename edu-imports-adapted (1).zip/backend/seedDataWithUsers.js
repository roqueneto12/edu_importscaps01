const mongoose = require('mongoose');
const dotenv = require('dotenv');
const User = require('./models/User');
const Product = require('./models/Product');

// Carregar variáveis de ambiente
dotenv.config();

// Dados de usuários de exemplo
const users = [
    {
        name: 'Administrador',
        email: 'admin@eduimports.com',
        password: '123456',
        role: 'admin'
    },
    {
        name: 'João Silva',
        email: 'joao@email.com',
        password: '123456',
        role: 'user'
    },
    {
        name: 'Maria Santos',
        email: 'maria@email.com',
        password: '123456',
        role: 'user'
    }
];

// Dados de produtos de exemplo
const products = [
    {
        name: "Lattafa Asad Eau de Parfum - Perfume Masculino 100ml",
        description: "Esta fragrância exala uma aura de poder e confiança, combinando notas intensas e profundas para criar uma experiência olfativa envolvente. Notas de Saída (Topo): A primeira impressão é vibrante e revigorante, com uma explosão de notas cítricas e frutadas.",
        price: 150,
        oldPrice: 200,
        image: "https://i.ibb.co/03GDKJb/Chat-GPT-Image-23-de-jul-de-2025-09-24-55.png",
        category: "perfumes",
        featured: true,
        inStock: true,
        stockQuantity: 25,
        sales: 150,
        rating: 4.8,
        tags: ["masculino", "lattafa", "eau de parfum", "100ml"]
    },
    {
        name: "Perfume Feminino Floral Elegance 50ml",
        description: "Uma fragrância delicada e sofisticada com notas florais que despertam os sentidos. Perfeito para o dia a dia ou ocasiões especiais.",
        price: 120,
        oldPrice: 160,
        image: "https://via.placeholder.com/300x300/ff69b4/ffffff?text=Floral+Elegance",
        category: "perfumes",
        featured: true,
        inStock: true,
        stockQuantity: 30,
        sales: 120,
        rating: 4.6,
        tags: ["feminino", "floral", "elegante", "50ml"]
    },
    {
        name: "Creme Hidratante Facial Premium",
        description: "Creme hidratante com ácido hialurônico e vitamina E. Proporciona hidratação profunda e anti-idade para todos os tipos de pele.",
        price: 80,
        oldPrice: 100,
        image: "https://via.placeholder.com/300x300/87ceeb/ffffff?text=Creme+Facial",
        category: "cosmeticos",
        featured: false,
        inStock: true,
        stockQuantity: 50,
        sales: 200,
        rating: 4.7,
        tags: ["hidratante", "facial", "anti-idade", "premium"]
    },
    {
        name: "Óculos de Sol Aviador Clássico",
        description: "Óculos de sol estilo aviador com lentes polarizadas e proteção UV400. Armação em metal resistente e design atemporal.",
        price: 95,
        oldPrice: 130,
        image: "https://via.placeholder.com/300x300/ffd700/000000?text=Aviador",
        category: "acessorios",
        featured: false,
        inStock: true,
        stockQuantity: 15,
        sales: 80,
        rating: 4.5,
        tags: ["óculos", "aviador", "polarizado", "uv400"]
    },
    {
        name: "Perfume Unissex Citrus Fresh 75ml",
        description: "Fragrância cítrica e refrescante, perfeita para qualquer ocasião. Notas de limão, bergamota e menta.",
        price: 110,
        image: "https://via.placeholder.com/300x300/32cd32/ffffff?text=Citrus+Fresh",
        category: "perfumes",
        featured: false,
        inStock: true,
        stockQuantity: 20,
        sales: 90,
        rating: 4.4,
        tags: ["unissex", "citrus", "refrescante", "75ml"]
    },
    {
        name: "Sérum Vitamina C Antioxidante",
        description: "Sérum facial com vitamina C pura, combate os radicais livres e proporciona luminosidade à pele.",
        price: 65,
        oldPrice: 85,
        image: "https://via.placeholder.com/300x300/ffa500/ffffff?text=Vitamina+C",
        category: "cosmeticos",
        featured: false,
        inStock: true,
        stockQuantity: 40,
        sales: 180,
        rating: 4.9,
        tags: ["sérum", "vitamina c", "antioxidante", "luminosidade"]
    }
];

const seedDatabase = async () => {
    try {
        // Conectar ao MongoDB
        await mongoose.connect(process.env.MONGODB_URI, {
            serverSelectionTimeoutMS: 5000,
            socketTimeoutMS: 45000,
        });

        console.log('✅ Conectado ao MongoDB');

        // Limpar dados existentes
        await User.deleteMany({});
        await Product.deleteMany({});
        console.log('🗑️  Dados existentes removidos');

        // Inserir usuários individualmente para acionar o middleware de hash de senha
        for (const userData of users) {
            await User.create(userData);
        }
        console.log("👥 Usuários de exemplo inseridos e senhas criptografadas");

        // Inserir produtos
        await Product.insertMany(products);
        console.log('📦 Produtos de exemplo inseridos');

        console.log('\n🎉 Banco de dados populado com sucesso!');
        console.log('\n📋 Credenciais de acesso:');
        console.log('👨‍💼 Admin: admin@eduimports.com / 123456');
        console.log('👤 Usuário: joao@email.com / 123456');
        console.log('👤 Usuário: maria@email.com / 123456');

        // Fechar conexão
        await mongoose.connection.close();
        console.log('🔌 Conexão fechada');
        
        process.exit(0);
    } catch (error) {
        console.error('❌ Erro ao popular banco de dados:', error);
        process.exit(1);
    }
};

// Executar apenas se chamado diretamente
if (require.main === module) {
    seedDatabase();
}

module.exports = { users, products, seedDatabase };

