const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Nome do produto é obrigatório'],
        trim: true,
        maxlength: [100, 'Nome não pode ter mais de 100 caracteres']
    },
    description: {
        type: String,
        required: [true, 'Descrição é obrigatória'],
        maxlength: [1000, 'Descrição não pode ter mais de 1000 caracteres']
    },
    price: {
        type: Number,
        required: [true, 'Preço é obrigatório'],
        min: [0, 'Preço não pode ser negativo']
    },
    oldPrice: {
        type: Number,
        min: [0, 'Preço antigo não pode ser negativo']
    },
    image: {
        type: String,
        required: [true, 'Imagem é obrigatória']
    },
    category: {
        type: String,
        required: [true, 'Categoria é obrigatória'],
        enum: ['perfumes', 'cosmeticos', 'acessorios', 'outros']
    },
    featured: {
        type: Boolean,
        default: false
    },
    inStock: {
        type: Boolean,
        default: true
    },
    stockQuantity: {
        type: Number,
        default: 0,
        min: [0, 'Quantidade em estoque não pode ser negativa']
    },
    sales: {
        type: Number,
        default: 0,
        min: [0, 'Vendas não podem ser negativas']
    },
    rating: {
        type: Number,
        default: 0,
        min: [0, 'Avaliação mínima é 0'],
        max: [5, 'Avaliação máxima é 5']
    },
    tags: [{
        type: String,
        trim: true
    }]
}, {
    timestamps: true
});

// Índices para melhor performance
productSchema.index({ name: 'text', description: 'text' });
productSchema.index({ category: 1 });
productSchema.index({ featured: 1 });
productSchema.index({ sales: -1 });

module.exports = mongoose.model('Product', productSchema);

