const mongoose = require('mongoose');

const locationSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Nome da localização é obrigatório'],
        trim: true
    },
    address: {
        type: String,
        required: [true, 'Endereço é obrigatório'],
        trim: true
    },
    latitude: {
        type: Number,
        required: [true, 'Latitude é obrigatória']
    },
    longitude: {
        type: Number,
        required: [true, 'Longitude é obrigatória']
    },
    phone: {
        type: String,
        required: [true, 'Telefone é obrigatório'],
        trim: true
    },
    email: {
        type: String,
        trim: true,
        match: [/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/, 'Por favor, use um email válido']
    },
    description: {
        type: String,
        trim: true
    },
    isActive: {
        type: Boolean,
        default: true
    }
}, {
    timestamps: true
});

module.exports = mongoose.model('Location', locationSchema);
