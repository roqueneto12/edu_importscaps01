const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: [true, 'Usuário é obrigatório']
    },
    product: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Product',
        required: [true, 'Produto é obrigatório']
    },
    quantity: {
        type: Number,
        default: 1,
        min: [1, 'Quantidade mínima é 1']
    },
    price: {
        type: Number,
        required: [true, 'Preço é obrigatório'],
        min: [0, 'Preço não pode ser negativo']
    },
    totalPrice: {
        type: Number,
        required: [true, 'Preço total é obrigatório'],
        min: [0, 'Preço total não pode ser negativo']
    },
    // Status do pedido: 'pending' (aguardando validação), 'confirmed' (validado pelo ADM), 'cancelled' (cancelado)
    status: {
        type: String,
        enum: ['pending', 'confirmed', 'cancelled'],
        default: 'pending'
    },
    // Data e hora do clique no WhatsApp
    whatsappClickedAt: {
        type: Date,
        default: Date.now
    },
    // Data e hora da validação pelo ADM
    validatedAt: Date,
    // Usuário ADM que validou
    validatedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    // Observações do ADM sobre a validação
    adminNotes: String
}, {
    timestamps: true
});

// Índices para melhor performance
orderSchema.index({ user: 1 });
orderSchema.index({ product: 1 });
orderSchema.index({ status: 1 });
orderSchema.index({ whatsappClickedAt: -1 });
orderSchema.index({ validatedAt: -1 });

module.exports = mongoose.model('Order', orderSchema);
