const Order = require('../models/Order');
const Product = require('../models/Product');
const User = require('../models/User');
const ExcelJS = require('exceljs');
const PDFDocument = require('pdfkit');

// @desc    Registrar um clique no WhatsApp (criar um pedido pendente)
// @route   POST /api/orders/whatsapp-click
// @access  Private (Cliente)
exports.registerWhatsappClick = async (req, res, next) => {
    try {
        const { productId, quantity = 1 } = req.body;
        const userId = req.user.id;

        // Validar produto
        const product = await Product.findById(productId);
        if (!product) {
            return res.status(404).json({
                success: false,
                message: 'Produto não encontrado'
            });
        }

        // Validar quantidade
        if (quantity < 1) {
            return res.status(400).json({
                success: false,
                message: 'Quantidade deve ser maior que 0'
            });
        }

        // Calcular preço total
        const totalPrice = product.price * quantity;

        // Criar novo pedido
        const order = await Order.create({
            user: userId,
            product: productId,
            quantity,
            price: product.price,
            totalPrice,
            status: 'pending'
        });

        // Preencher dados do usuário e produto
        await order.populate('user', 'name email');
        await order.populate('product', 'name price');

        res.status(201).json({
            success: true,
            message: 'Clique no WhatsApp registrado com sucesso',
            data: order
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Listar todos os pedidos pendentes (para ADM)
// @route   GET /api/orders/pending
// @access  Private (Admin)
exports.getPendingOrders = async (req, res, next) => {
    try {
        const orders = await Order.find({ status: 'pending' })
            .populate('user', 'name email')
            .populate('product', 'name price image')
            .sort({ whatsappClickedAt: -1 });

        res.status(200).json({
            success: true,
            count: orders.length,
            data: orders
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Listar todos os pedidos (com filtros opcionais)
// @route   GET /api/orders
// @access  Private (Admin)
exports.getAllOrders = async (req, res, next) => {
    try {
        const { status, userId, startDate, endDate } = req.query;
        const filter = {};

        if (status) filter.status = status;
        if (userId) filter.user = userId;
        if (startDate || endDate) {
            filter.whatsappClickedAt = {};
            if (startDate) filter.whatsappClickedAt.$gte = new Date(startDate);
            if (endDate) filter.whatsappClickedAt.$lte = new Date(endDate);
        }

        const orders = await Order.find(filter)
            .populate('user', 'name email')
            .populate('product', 'name price image')
            .populate('validatedBy', 'name email')
            .sort({ whatsappClickedAt: -1 });

        res.status(200).json({
            success: true,
            count: orders.length,
            data: orders
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Obter detalhes de um pedido específico
// @route   GET /api/orders/:id
// @access  Private
exports.getOrderById = async (req, res, next) => {
    try {
        const order = await Order.findById(req.params.id)
            .populate('user', 'name email')
            .populate('product', 'name price image description')
            .populate('validatedBy', 'name email');

        if (!order) {
            return res.status(404).json({
                success: false,
                message: 'Pedido não encontrado'
            });
        }

        // Verificar se o usuário tem permissão para ver este pedido
        if (req.user.role !== 'admin' && order.user.toString() !== req.user.id) {
            return res.status(403).json({
                success: false,
                message: 'Você não tem permissão para acessar este pedido'
            });
        }

        res.status(200).json({
            success: true,
            data: order
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Validar um pedido (confirmar compra)
// @route   PUT /api/orders/:id/validate
// @access  Private (Admin)
exports.validateOrder = async (req, res, next) => {
    try {
        const { adminNotes } = req.body;
        const orderId = req.params.id;
        const adminId = req.user.id;

        // Buscar o pedido
        const order = await Order.findById(orderId);
        if (!order) {
            return res.status(404).json({
                success: false,
                message: 'Pedido não encontrado'
            });
        }

        // Verificar se o pedido já foi validado
        if (order.status !== 'pending') {
            return res.status(400).json({
                success: false,
                message: `Pedido já foi ${order.status === 'confirmed' ? 'confirmado' : 'cancelado'}`
            });
        }

        // Atualizar o pedido
        order.status = 'confirmed';
        order.validatedAt = new Date();
        order.validatedBy = adminId;
        order.adminNotes = adminNotes || '';

        await order.save();

        // Preencher dados
        await order.populate('user', 'name email');
        await order.populate('product', 'name price');
        await order.populate('validatedBy', 'name email');

        res.status(200).json({
            success: true,
            message: 'Pedido validado com sucesso',
            data: order
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Cancelar um pedido
// @route   PUT /api/orders/:id/cancel
// @access  Private (Admin)
exports.cancelOrder = async (req, res, next) => {
    try {
        const { adminNotes } = req.body;
        const orderId = req.params.id;
        const adminId = req.user.id;

        // Buscar o pedido
        const order = await Order.findById(orderId);
        if (!order) {
            return res.status(404).json({
                success: false,
                message: 'Pedido não encontrado'
            });
        }

        // Verificar se o pedido já foi processado
        if (order.status !== 'pending') {
            return res.status(400).json({
                success: false,
                message: `Pedido já foi ${order.status === 'confirmed' ? 'confirmado' : 'cancelado'}`
            });
        }

        // Atualizar o pedido
        order.status = 'cancelled';
        order.validatedAt = new Date();
        order.validatedBy = adminId;
        order.adminNotes = adminNotes || '';

        await order.save();

        // Preencher dados
        await order.populate('user', 'name email');
        await order.populate('product', 'name price');
        await order.populate('validatedBy', 'name email');

        res.status(200).json({
            success: true,
            message: 'Pedido cancelado com sucesso',
            data: order
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Gerar relatório de vendas em Excel
// @route   GET /api/orders/report/excel
// @access  Private (Admin)
exports.generateExcelReport = async (req, res, next) => {
    try {
        // Buscar apenas pedidos confirmados
        const orders = await Order.find({ status: 'confirmed' })
            .populate('user', 'name email')
            .populate('product', 'name price category')
            .populate('validatedBy', 'name')
            .sort({ validatedAt: -1 });

        // Criar workbook
        const workbook = new ExcelJS.Workbook();
        const worksheet = workbook.addWorksheet('Vendas');

        // Adicionar cabeçalho
        worksheet.columns = [
            { header: 'ID Pedido', key: '_id', width: 20 },
            { header: 'Cliente', key: 'clientName', width: 20 },
            { header: 'Email', key: 'clientEmail', width: 25 },
            { header: 'Produto', key: 'productName', width: 25 },
            { header: 'Categoria', key: 'category', width: 15 },
            { header: 'Quantidade', key: 'quantity', width: 12 },
            { header: 'Preço Unitário', key: 'price', width: 15 },
            { header: 'Preço Total', key: 'totalPrice', width: 15 },
            { header: 'Data do Clique', key: 'whatsappClickedAt', width: 20 },
            { header: 'Data da Validação', key: 'validatedAt', width: 20 },
            { header: 'Validado por', key: 'validatedByName', width: 20 }
        ];

        // Adicionar dados
        orders.forEach(order => {
            worksheet.addRow({
                _id: order._id.toString(),
                clientName: order.user.name,
                clientEmail: order.user.email,
                productName: order.product.name,
                category: order.product.category,
                quantity: order.quantity,
                price: `R$ ${order.price.toFixed(2)}`,
                totalPrice: `R$ ${order.totalPrice.toFixed(2)}`,
                whatsappClickedAt: new Date(order.whatsappClickedAt).toLocaleString('pt-BR'),
                validatedAt: new Date(order.validatedAt).toLocaleString('pt-BR'),
                validatedByName: order.validatedBy.name
            });
        });

        // Estilizar cabeçalho
        worksheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
        worksheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF4472C4' } };

        // Gerar arquivo
        const buffer = await workbook.xlsx.writeBuffer();

        // Enviar arquivo
        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        res.setHeader('Content-Disposition', `attachment; filename="relatorio_vendas_${new Date().toISOString().split('T')[0]}.xlsx"`);
        res.send(buffer);
    } catch (error) {
        next(error);
    }
};

// @desc    Gerar relatório de vendas em PDF
// @route   GET /api/orders/report/pdf
// @access  Private (Admin)
exports.generatePdfReport = async (req, res, next) => {
    try {
        // Buscar apenas pedidos confirmados
        const orders = await Order.find({ status: 'confirmed' })
            .populate('user', 'name email')
            .populate('product', 'name price category')
            .populate('validatedBy', 'name')
            .sort({ validatedAt: -1 });

        // Calcular totais
        const totalRevenue = orders.reduce((sum, order) => sum + order.totalPrice, 0);
        const totalOrders = orders.length;

        // Criar documento PDF
        const doc = new PDFDocument({ margin: 40 });

        // Configurar resposta
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', `attachment; filename="relatorio_vendas_${new Date().toISOString().split('T')[0]}.pdf"`);

        // Pipe do documento para a resposta
        doc.pipe(res);

        // Título
        doc.fontSize(20).font('Helvetica-Bold').text('RELATÓRIO DE VENDAS', { align: 'center' });
        doc.fontSize(12).font('Helvetica').text(`Data: ${new Date().toLocaleString('pt-BR')}`, { align: 'center' });
        doc.moveDown();

        // Resumo
        doc.fontSize(14).font('Helvetica-Bold').text('RESUMO');
        doc.fontSize(11).font('Helvetica');
        doc.text(`Total de Vendas: ${totalOrders}`);
        doc.text(`Receita Total: R$ ${totalRevenue.toFixed(2)}`);
        doc.moveDown();

        // Tabela de vendas
        doc.fontSize(14).font('Helvetica-Bold').text('DETALHES DAS VENDAS');
        doc.moveDown(0.5);

        // Cabeçalho da tabela
        const tableTop = doc.y;
        const col1 = 40;
        const col2 = 150;
        const col3 = 280;
        const col4 = 380;
        const col5 = 480;

        doc.fontSize(10).font('Helvetica-Bold');
        doc.text('Cliente', col1, tableTop);
        doc.text('Produto', col2, tableTop);
        doc.text('Qtd', col3, tableTop);
        doc.text('Valor Total', col4, tableTop);
        doc.text('Data Validação', col5, tableTop);

        // Linha separadora
        doc.moveTo(col1, tableTop + 15).lineTo(550, tableTop + 15).stroke();

        // Dados da tabela
        let yPosition = tableTop + 25;
        doc.fontSize(9).font('Helvetica');

        orders.forEach((order, index) => {
            if (yPosition > 700) {
                doc.addPage();
                yPosition = 40;
            }

            doc.text(order.user.name.substring(0, 20), col1, yPosition);
            doc.text(order.product.name.substring(0, 20), col2, yPosition);
            doc.text(order.quantity.toString(), col3, yPosition);
            doc.text(`R$ ${order.totalPrice.toFixed(2)}`, col4, yPosition);
            doc.text(new Date(order.validatedAt).toLocaleDateString('pt-BR'), col5, yPosition);

            yPosition += 15;
        });

        // Finalizar documento
        doc.end();
    } catch (error) {
        next(error);
    }
};

// @desc    Obter estatísticas de vendas
// @route   GET /api/orders/stats
// @access  Private (Admin)
exports.getOrderStats = async (req, res, next) => {
    try {
        const totalOrders = await Order.countDocuments();
        const pendingOrders = await Order.countDocuments({ status: 'pending' });
        const confirmedOrders = await Order.countDocuments({ status: 'confirmed' });
        const cancelledOrders = await Order.countDocuments({ status: 'cancelled' });

        const confirmedOrdersData = await Order.find({ status: 'confirmed' });
        const totalRevenue = confirmedOrdersData.reduce((sum, order) => sum + order.totalPrice, 0);

        res.status(200).json({
            success: true,
            data: {
                totalOrders,
                pendingOrders,
                confirmedOrders,
                cancelledOrders,
                totalRevenue: totalRevenue.toFixed(2)
            }
        });
    } catch (error) {
        next(error);
    }
};
