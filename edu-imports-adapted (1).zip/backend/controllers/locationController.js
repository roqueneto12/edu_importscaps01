const Location = require('../models/Location');

// @desc    Obter todas as localizações ativas
// @route   GET /api/locations
// @access  Public
exports.getLocations = async (req, res, next) => {
    try {
        const locations = await Location.find({ isActive: true });

        res.status(200).json({
            success: true,
            count: locations.length,
            data: locations
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Obter uma localização específica
// @route   GET /api/locations/:id
// @access  Public
exports.getLocationById = async (req, res, next) => {
    try {
        const location = await Location.findById(req.params.id);

        if (!location) {
            return res.status(404).json({
                success: false,
                message: 'Localização não encontrada'
            });
        }

        res.status(200).json({
            success: true,
            data: location
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Criar uma nova localização (Admin)
// @route   POST /api/locations
// @access  Private (Admin)
exports.createLocation = async (req, res, next) => {
    try {
        const { name, address, latitude, longitude, phone, email, description } = req.body;

        // Validar dados obrigatórios
        if (!name || !address || latitude === undefined || longitude === undefined || !phone) {
            return res.status(400).json({
                success: false,
                message: 'Por favor, preencha todos os campos obrigatórios'
            });
        }

        const location = await Location.create({
            name,
            address,
            latitude,
            longitude,
            phone,
            email,
            description
        });

        res.status(201).json({
            success: true,
            message: 'Localização criada com sucesso',
            data: location
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Atualizar uma localização (Admin)
// @route   PUT /api/locations/:id
// @access  Private (Admin)
exports.updateLocation = async (req, res, next) => {
    try {
        const { name, address, latitude, longitude, phone, email, description, isActive } = req.body;

        let location = await Location.findById(req.params.id);

        if (!location) {
            return res.status(404).json({
                success: false,
                message: 'Localização não encontrada'
            });
        }

        // Atualizar campos
        if (name) location.name = name;
        if (address) location.address = address;
        if (latitude !== undefined) location.latitude = latitude;
        if (longitude !== undefined) location.longitude = longitude;
        if (phone) location.phone = phone;
        if (email) location.email = email;
        if (description) location.description = description;
        if (isActive !== undefined) location.isActive = isActive;

        await location.save();

        res.status(200).json({
            success: true,
            message: 'Localização atualizada com sucesso',
            data: location
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Deletar uma localização (Admin)
// @route   DELETE /api/locations/:id
// @access  Private (Admin)
exports.deleteLocation = async (req, res, next) => {
    try {
        const location = await Location.findByIdAndDelete(req.params.id);

        if (!location) {
            return res.status(404).json({
                success: false,
                message: 'Localização não encontrada'
            });
        }

        res.status(200).json({
            success: true,
            message: 'Localização deletada com sucesso'
        });
    } catch (error) {
        next(error);
    }
};
