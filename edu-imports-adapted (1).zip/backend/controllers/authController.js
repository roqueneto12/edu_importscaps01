const User = require('../models/User');

// @desc    Registrar usuário
// @route   POST /api/auth/register
// @access  Public
const register = async (req, res) => {
    try {
        const { name, email, password } = req.body;

        // Verificar se o usuário já existe
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({
                success: false,
                message: 'Usuário já existe com este email'
            });
        }

        // Criar usuário
        const user = await User.create({
            name,
            email,
            password
        });

        sendTokenResponse(user, 201, res, 'Usuário registrado com sucesso');
    } catch (error) {
        res.status(400).json({
            success: false,
            message: 'Erro ao registrar usuário',
            error: error.message
        });
    }
};

// @desc    Login do usuário
// @route   POST /api/auth/login
// @access  Public
const login = async (req, res) => {
    try {
        const { email, password } = req.body;

        console.log(`[LOGIN ATTEMPT] Email: ${email}, Password: ${password}`);

        // Validar email e senha
        if (!email || !password) {
            console.log("[LOGIN FAILED] Email ou senha não fornecidos.");
            return res.status(400).json({
                success: false,
                message: "Por favor, forneça email e senha"
            });
        }

        // Verificar se o usuário existe
        const user = await User.findOne({ email }).select("+password");
        if (!user) {
            console.log(`[LOGIN FAILED] Usuário não encontrado para o email: ${email}`);
            return res.status(401).json({
                success: false,
                message: "Credenciais inválidas"
            });
        }

        console.log(`[LOGIN INFO] Usuário encontrado: ${user.email}`);

        // Verificar senha
        const isMatch = await user.matchPassword(password);
        if (!isMatch) {
            console.log(`[LOGIN FAILED] Senha incorreta para o usuário: ${email}`);
            return res.status(401).json({
                success: false,
                message: "Credenciais inválidas"
            });
        }

        console.log(`[LOGIN SUCCESS] Login bem-sucedido para o usuário: ${email}`);
        sendTokenResponse(user, 200, res, "Login realizado com sucesso");
    } catch (error) {
        console.error(`[LOGIN ERROR] Erro interno do servidor durante o login: ${error.message}`);
        res.status(500).json({
            success: false,
            message: "Erro no servidor",
            error: error.message
        });
    }
};

// @desc    Obter usuário atual
// @route   GET /api/auth/me
// @access  Private
const getMe = async (req, res) => {
    try {
        const user = await User.findById(req.user.id);
        
        res.status(200).json({
            success: true,
            data: user
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Erro ao buscar usuário',
            error: error.message
        });
    }
};

// @desc    Logout do usuário
// @route   POST /api/auth/logout
// @access  Private
const logout = async (req, res) => {
    res.status(200).json({
        success: true,
        message: 'Logout realizado com sucesso',
        data: {}
    });
};

// Função auxiliar para enviar token na resposta
const sendTokenResponse = (user, statusCode, res, message) => {
    // Criar token
    const token = user.getSignedJwtToken();

    const options = {
        expires: new Date(
            Date.now() + process.env.JWT_COOKIE_EXPIRE * 24 * 60 * 60 * 1000
        ),
        httpOnly: true
    };

    if (process.env.NODE_ENV === 'production') {
        options.secure = true;
    }

    res.status(statusCode)
        .cookie('token', token, options)
        .json({
            success: true,
            message,
            token,
            data: {
                id: user._id,
                name: user.name,
                email: user.email,
                role: user.role
            }
        });
};

module.exports = {
    register,
    login,
    getMe,
    logout
};

