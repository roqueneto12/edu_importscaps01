const Product = require('../models/Product');

// @desc    Obter todos os produtos
// @route   GET /api/products
// @access  Public
const getProducts = async (req, res) => {
    try {
        const { 
            category, 
            featured, 
            search, 
            sort = '-createdAt', 
            page = 1, 
            limit = 10 
        } = req.query;

        // Construir filtros
        const filter = {};
        
        if (category) {
            filter.category = category;
        }
        
        if (featured !== undefined) {
            filter.featured = featured === 'true';
        }
        
        if (search) {
            filter.$text = { $search: search };
        }

        // Calcular paginação
        const skip = (page - 1) * limit;

        // Buscar produtos
        const products = await Product.find(filter)
            .sort(sort)
            .skip(skip)
            .limit(parseInt(limit));

        // Contar total de produtos
        const total = await Product.countDocuments(filter);

        res.status(200).json({
            success: true,
            count: products.length,
            total,
            page: parseInt(page),
            pages: Math.ceil(total / limit),
            data: products
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Erro ao buscar produtos',
            error: error.message
        });
    }
};

// @desc    Obter produto por ID
// @route   GET /api/products/:id
// @access  Public
const getProduct = async (req, res) => {
    try {
        const product = await Product.findById(req.params.id);

        if (!product) {
            return res.status(404).json({
                success: false,
                message: 'Produto não encontrado'
            });
        }

        res.status(200).json({
            success: true,
            data: product
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Erro ao buscar produto',
            error: error.message
        });
    }
};

// @desc    Criar novo produto
// @route   POST /api/products
// @access  Private (Admin)
const createProduct = async (req, res) => {
    try {
        const product = await Product.create(req.body);

        res.status(201).json({
            success: true,
            message: 'Produto criado com sucesso',
            data: product
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            message: 'Erro ao criar produto',
            error: error.message
        });
    }
};

// @desc    Atualizar produto
// @route   PUT /api/products/:id
// @access  Private (Admin)
const updateProduct = async (req, res) => {
    try {
        const product = await Product.findByIdAndUpdate(
            req.params.id,
            req.body,
            {
                new: true,
                runValidators: true
            }
        );

        if (!product) {
            return res.status(404).json({
                success: false,
                message: 'Produto não encontrado'
            });
        }

        res.status(200).json({
            success: true,
            message: 'Produto atualizado com sucesso',
            data: product
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            message: 'Erro ao atualizar produto',
            error: error.message
        });
    }
};

// @desc    Deletar produto
// @route   DELETE /api/products/:id
// @access  Private (Admin)
const deleteProduct = async (req, res) => {
    try {
        const product = await Product.findByIdAndDelete(req.params.id);

        if (!product) {
            return res.status(404).json({
                success: false,
                message: 'Produto não encontrado'
            });
        }

        res.status(200).json({
            success: true,
            message: 'Produto deletado com sucesso'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Erro ao deletar produto',
            error: error.message
        });
    }
};

// @desc    Obter produtos em destaque
// @route   GET /api/products/featured
// @access  Public
const getFeaturedProducts = async (req, res) => {
    try {
        const products = await Product.find({ featured: true })
            .sort('-createdAt')
            .limit(6);

        res.status(200).json({
            success: true,
            count: products.length,
            data: products
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Erro ao buscar produtos em destaque',
            error: error.message
        });
    }
};

// @desc    Obter ranking de produtos (mais vendidos)
// @route   GET /api/products/ranking
// @access  Public
const getProductRanking = async (req, res) => {
    try {
        const products = await Product.find()
            .sort('-sales')
            .limit(10)
            .select('name sales rating price image');

        res.status(200).json({
            success: true,
            count: products.length,
            data: products
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Erro ao buscar ranking de produtos',
            error: error.message
        });
    }
};

module.exports = {
    getProducts,
    getProduct,
    createProduct,
    updateProduct,
    deleteProduct,
    getFeaturedProducts,
    getProductRanking
};

