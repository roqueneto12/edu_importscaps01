# 🛍️ Edu_Imports - Loja Online Completa

Um projeto fullstack completo para e-commerce com autenticação de usuários, gerenciamento de produtos por administradores e carrinho de compras.

## 🚀 Funcionalidades Implementadas

### 👤 **Sistema de Usuários**
- ✅ Cadastro de novos usuários
- ✅ Login/Logout com autenticação JWT
- ✅ Diferentes níveis de acesso (Admin/Usuário)
- ✅ Proteção de rotas sensíveis

### 🛒 **Carrinho de Compras**
- ✅ Adicionar produtos ao carrinho
- ✅ Atualizar quantidades
- ✅ Remover itens
- ✅ Calcular totais automaticamente
- ✅ Persistência por usuário

### 👨‍💼 **Painel Administrativo**
- ✅ Criar novos produtos
- ✅ Editar produtos existentes
- ✅ Excluir produtos
- ✅ Gerenciar estoque
- ✅ Definir produtos em destaque

### 🎨 **Interface do Usuário**
- ✅ Design responsivo e moderno
- ✅ Produtos em destaque
- ✅ Catálogo completo de produtos
- ✅ Modais para login/registro/carrinho
- ✅ Alertas e notificações

## 📁 Estrutura do Projeto

```
edu-imports-fullstack/
├── backend/                     # API Node.js/Express.js
│   ├── config/
│   │   └── database.js         # Configuração MongoDB
│   ├── controllers/
│   │   ├── authController.js   # Autenticação
│   │   ├── cartController.js   # Carrinho
│   │   └── productController.js # Produtos
│   ├── middleware/
│   │   ├── auth.js            # Middleware de autenticação
│   │   └── errorHandler.js    # Tratamento de erros
│   ├── models/
│   │   ├── User.js            # Modelo de usuário
│   │   ├── Product.js         # Modelo de produto
│   │   └── Cart.js            # Modelo de carrinho
│   ├── routes/
│   │   ├── auth.js            # Rotas de autenticação
│   │   ├── cart.js            # Rotas do carrinho
│   │   └── products.js        # Rotas de produtos
│   ├── .env                   # Variáveis de ambiente
│   ├── package.json           # Dependências do backend
│   ├── server.js              # Servidor principal
│   └── seedDataWithUsers.js   # Dados de exemplo
├── frontend.html              # Frontend original
├── frontend-complete.html     # Frontend com todas as funcionalidades
└── README-COMPLETO.md         # Esta documentação
```

## 🛠️ Como Configurar e Rodar

### 1. **Configurar o Backend**

1. **Navegue até a pasta do backend:**
   ```bash
   cd backend
   ```

2. **Instale as dependências:**
   ```bash
   npm install
   ```

3. **Configure o banco de dados:**
   
   **Opção A - MongoDB Local:**
   ```bash
   # Ubuntu/Debian
   sudo apt-get install mongodb
   sudo systemctl start mongod
   
   # macOS
   brew install mongodb-community
   brew services start mongodb-community
   ```
   
   **Opção B - Docker (Recomendado):**
   ```bash
   docker run -d -p 27017:27017 --name mongodb mongo
   ```
   
   **Opção C - MongoDB Atlas (Nuvem):**
   - Crie uma conta em https://cloud.mongodb.com
   - Crie um cluster gratuito
   - Obtenha a string de conexão
   - Atualize o arquivo `.env`

4. **Configure as variáveis de ambiente:**
   ```bash
   # O arquivo .env já está configurado, mas você pode ajustar:
   MONGODB_URI=mongodb://localhost:27017/edu_imports
   JWT_SECRET=seu_jwt_secret_super_seguro
   PORT=3000
   ```

5. **Popule o banco com dados de exemplo:**
   ```bash
   npm run seed
   ```
   
   Isso criará:
   - **Admin:** admin@eduimports.com / 123456
   - **Usuários:** joao@email.com / 123456, maria@email.com / 123456
   - **Produtos:** 6 produtos de exemplo

6. **Inicie o servidor:**
   ```bash
   npm run dev
   ```
   
   O servidor estará rodando em: http://localhost:3000

### 2. **Configurar o Frontend**

1. **Abra o arquivo `frontend-complete.html`** no seu navegador
2. **Ou sirva via servidor local** (recomendado):
   ```bash
   # Se você tem Python instalado:
   python -m http.server 8080
   
   # Ou se você tem Node.js:
   npx serve .
   ```

## 🔐 Credenciais de Teste

Após rodar `npm run seed`, você pode usar estas credenciais:

### 👨‍💼 **Administrador**
- **Email:** admin@eduimports.com
- **Senha:** 123456
- **Permissões:** Gerenciar produtos, ver painel admin

### 👤 **Usuários Normais**
- **Email:** joao@email.com ou maria@email.com
- **Senha:** 123456
- **Permissões:** Comprar produtos, gerenciar carrinho

## 📚 API Endpoints

### 🔐 **Autenticação**
```http
POST /api/auth/register    # Cadastrar usuário
POST /api/auth/login       # Fazer login
GET  /api/auth/me          # Obter usuário atual
POST /api/auth/logout      # Fazer logout
```

### 📦 **Produtos**
```http
GET    /api/products           # Listar produtos
GET    /api/products/featured  # Produtos em destaque
GET    /api/products/ranking   # Ranking de vendas
GET    /api/products/:id       # Obter produto específico
POST   /api/products           # Criar produto (Admin)
PUT    /api/products/:id       # Atualizar produto (Admin)
DELETE /api/products/:id       # Excluir produto (Admin)
```

### 🛒 **Carrinho**
```http
GET    /api/cart               # Obter carrinho
POST   /api/cart/add           # Adicionar item
PUT    /api/cart/update        # Atualizar quantidade
DELETE /api/cart/remove/:id    # Remover item
DELETE /api/cart/clear         # Limpar carrinho
```

## 🎯 Como Usar o Sistema

### **Para Usuários Normais:**

1. **Cadastre-se** clicando em "Cadastrar" no menu
2. **Faça login** com suas credenciais
3. **Navegue pelos produtos** na página inicial
4. **Adicione produtos ao carrinho** clicando em "Adicionar ao Carrinho"
5. **Gerencie seu carrinho** clicando no ícone do carrinho
6. **Finalize a compra** (funcionalidade em desenvolvimento)

### **Para Administradores:**

1. **Faça login** com credenciais de admin
2. **Acesse o painel admin** clicando em "Admin" no menu
3. **Adicione novos produtos** preenchendo o formulário
4. **Edite produtos existentes** clicando em "Editar" na tabela
5. **Exclua produtos** clicando em "Excluir" (com confirmação)
6. **Marque produtos como destaque** usando o checkbox

## 🔧 Tecnologias Utilizadas

### **Backend:**
- **Node.js** - Runtime JavaScript
- **Express.js** - Framework web
- **MongoDB** - Banco de dados NoSQL
- **Mongoose** - ODM para MongoDB
- **JWT** - Autenticação via tokens
- **bcryptjs** - Criptografia de senhas
- **CORS** - Controle de acesso entre origens

### **Frontend:**
- **Vue.js 3** - Framework JavaScript reativo
- **Axios** - Cliente HTTP para API
- **CSS3** - Estilização avançada
- **HTML5** - Estrutura semântica

## 🚀 Funcionalidades Avançadas

### **Segurança:**
- ✅ Senhas criptografadas com bcrypt
- ✅ Autenticação JWT com expiração
- ✅ Proteção de rotas por role (admin/user)
- ✅ Validação de dados de entrada
- ✅ Sanitização de dados

### **Performance:**
- ✅ Índices no banco de dados
- ✅ Paginação de produtos
- ✅ Lazy loading de dados
- ✅ Cache de autenticação

### **UX/UI:**
- ✅ Design responsivo (mobile-first)
- ✅ Animações e transições suaves
- ✅ Feedback visual (alertas, loading)
- ✅ Modais para ações importantes

## 🐛 Solução de Problemas

### **Backend não inicia:**
```bash
# Verificar se o MongoDB está rodando
sudo systemctl status mongod

# Verificar se a porta 3000 está livre
lsof -i :3000

# Verificar logs do servidor
npm run dev
```

### **Frontend não conecta com API:**
- Verifique se o backend está rodando na porta 3000
- Confirme que não há bloqueio de CORS
- Abra o console do navegador para ver erros

### **Erro de autenticação:**
- Limpe o localStorage do navegador
- Verifique se o JWT_SECRET está configurado
- Confirme que o usuário existe no banco

### **Produtos não aparecem:**
- Execute `npm run seed` para popular o banco
- Verifique a conexão com MongoDB
- Confirme que não há erros na API

## 📈 Próximas Funcionalidades

- [ ] **Sistema de Pagamento** (Stripe/PayPal)
- [ ] **Histórico de Pedidos**
- [ ] **Sistema de Avaliações**
- [ ] **Busca Avançada** com filtros
- [ ] **Notificações por Email**
- [ ] **Dashboard de Vendas**
- [ ] **Sistema de Cupons**
- [ ] **Chat de Suporte**

## 🤝 Para Desenvolvedores Júnior

### **Conceitos Importantes:**

1. **API RESTful:** O backend segue padrões REST para comunicação
2. **JWT:** Tokens para manter usuários logados de forma segura
3. **CRUD:** Create, Read, Update, Delete - operações básicas
4. **Middleware:** Funções que executam entre requisição e resposta
5. **MVC:** Model-View-Controller - padrão de arquitetura

### **Dicas de Estudo:**

- **MongoDB:** Aprenda sobre bancos NoSQL e documentos
- **Express.js:** Framework essencial para APIs Node.js
- **Vue.js:** Framework reativo para interfaces dinâmicas
- **Autenticação:** Entenda JWT e segurança web
- **Git:** Versionamento de código (essencial!)

### **Comandos Úteis:**

```bash
# Instalar dependências
npm install

# Rodar em desenvolvimento
npm run dev

# Popular banco de dados
npm run seed

# Ver logs do MongoDB
tail -f /var/log/mongodb/mongod.log

# Testar API com curl
curl -X GET http://localhost:3000/api/products
```

## 📞 Suporte

Para dúvidas ou problemas:

1. **Verifique os logs** do servidor e do navegador
2. **Consulte a documentação** das tecnologias usadas
3. **Teste os endpoints** com Postman ou Insomnia
4. **Verifique as variáveis de ambiente**

---

**Desenvolvido para Edu_Imports** 🛍️

*Este projeto demonstra um e-commerce completo com autenticação, autorização, carrinho de compras e painel administrativo, ideal para aprendizado e uso comercial.*

