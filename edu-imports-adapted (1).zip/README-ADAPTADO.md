# 🚀 Edu_Imports - Projeto Adaptado (Full-Stack)

Este documento detalha as modificações e novas funcionalidades implementadas no projeto original Edu_Imports, conforme as solicitações de adaptação.

## 🎯 Novas Funcionalidades

O sistema foi aprimorado com foco em **simplicidade, segurança no controle de acesso e clareza na visualização das vendas para o administrador (ADM)**.

### 1. Fluxo de Vendas e Validação via WhatsApp

O processo de compra foi transformado em um fluxo de **pré-venda** que requer validação manual do ADM.

| Funcionalidade | Detalhe |
| :--- | :--- |
| **Registro de Clique** | Ao clicar em "Comprar no WhatsApp", o sistema registra um **Pedido Pendente** no banco de dados, contendo dados do cliente e do produto. |
| **Redirecionamento** | O cliente é imediatamente redirecionado para o WhatsApp com a mensagem pré-formatada. |
| **Painel de Validação (ADM)** | O ADM acessa o Painel Admin para visualizar todos os Pedidos Pendentes. |
| **Validação Manual** | O ADM deve validar manualmente se a compra foi concluída no WhatsApp. |
| **Status** | Apenas após a validação do ADM, o pedido muda de `pending` para `confirmed` e é considerado uma venda. |

### 2. Relatórios de Vendas Exclusivos para ADM

Foram implementados endpoints para geração de relatórios de vendas, acessíveis apenas pelo administrador.

| Relatório | Formato | Conteúdo |
| :--- | :--- | :--- |
| **Relatório de Vendas** | **PDF** | Resumo de receita e lista detalhada de todas as vendas **confirmadas**. |
| **Relatório de Vendas** | **Excel (XLSX)** | Tabela completa e exportável de todas as vendas **confirmadas**, ideal para análise de dados. |

### 3. Mapa e Localização da Loja

| Funcionalidade | Detalhe |
| :--- | :--- |
| **API de Localização** | Novo endpoint `/api/locations` para gerenciar as localizações da loja. |
| **Mapa Interativo** | O frontend inclui uma nova seção "Localização" com um mapa interativo (Leaflet) exibindo o endereço fixo da loja. |
| **Endereço Fixo** | O sistema está configurado para exibir a localização correspondente ao link: `https://maps.app.goo.gl/eoCChVdGycjF4p6fA` (coordenadas: Latitude: -12.9714, Longitude: -38.5104). |

### 4. Controle de Acesso Simplificado

O sistema de autenticação foi simplificado para focar apenas em clientes e administradores.

| Tipo de Usuário | Permissões |
| :--- | :--- |
| **Cliente (`user`)** | Cadastro, Login, Visualização de Produtos, Registro de Cliques no WhatsApp. |
| **Administrador (`admin`)** | Todas as permissões de Cliente, além de: Acesso ao Painel Admin, Validação/Cancelamento de Pedidos, Geração de Relatórios. |
| **Remoção** | O sistema de cadastro de funcionários foi removido, mantendo apenas o fluxo Cliente/ADM. |

## 🛠️ Alterações no Código (Backend)

| Arquivo | Alterações |
| :--- | :--- |
| `backend/models/Order.js` | **NOVO:** Modelo para registrar pedidos com status (`pending`, `confirmed`, `cancelled`). |
| `backend/models/Location.js` | **NOVO:** Modelo para armazenar coordenadas e informações da loja. |
| `backend/controllers/orderController.js` | **NOVO:** Lógica para registrar cliques, validar/cancelar pedidos, e gerar relatórios (ExcelJS, PDFKit). |
| `backend/controllers/locationController.js` | **NOVO:** Lógica para gerenciar as localizações da loja. |
| `backend/routes/orders.js` | **NOVO:** Rotas para pedidos (registro, validação, relatórios). |
| `backend/routes/locations.js` | **NOVO:** Rotas para localização (visualização pública, CRUD do ADM). |
| `backend/server.js` | Inclusão das novas rotas `/api/orders` e `/api/locations`. |
| `backend/package.json` | Adição das dependências `exceljs` e `pdfkit`. |

## 🎨 Alterações no Código (Frontend)

O arquivo `frontend-whatsapp.html` foi substituído por `frontend-adapted.html` para incorporar as novas funcionalidades.

| Arquivo | Alterações |
| :--- | :--- |
| `frontend-adapted.html` | **NOVO:** Frontend completo em Vue.js com: |
| | - Integração com a API de Pedidos (`/orders/whatsapp-click`). |
| | - Seção "Localização" com mapa Leaflet e informações da loja. |
| | - Painel Admin com abas para Pedidos Pendentes, Todos os Pedidos, Relatórios e Estatísticas. |
| | - Funções para `validateOrder`, `cancelOrder`, `downloadExcelReport` e `downloadPdfReport`. |

## ⚙️ Como Rodar o Projeto Adaptado

### 1. Configurar o Backend

1.  **Navegue até a pasta do backend:**
    ```bash
    cd edu-imports-adapted/backend
    ```

2.  **Instale as novas dependências:**
    ```bash
    npm install
    ```

3.  **Configure o banco de dados (MongoDB):**
    *   Crie o arquivo `.env` na pasta `backend` (copiando de `.env.example`).
    *   Defina sua string de conexão `MONGODB_URI`.

4.  **Popule o banco com dados de exemplo (Usuários e Produtos):**
    ```bash
    npm run seed
    ```
    *   **Credenciais ADM:** `admin@eduimports.com` / `123456`

5.  **Adicione a Localização Fixa (Opcional, mas recomendado):**
    *   Após iniciar o servidor (Passo 6), use uma ferramenta como Postman para criar a localização via API (requer token ADM):
        *   **Endpoint:** `POST http://localhost:3000/api/locations`
        *   **Body (JSON):**
            ```json
            {
                "name": "Sede Principal",
                "address": "R. Dr. José Peroba, 275 - Stiep, Salvador - BA, 41770-235",
                "latitude": -12.9714,
                "longitude": -38.5104,
                "phone": "7182362019",
                "email": "contato@eduimports.com",
                "description": "Localização fixa da loja para retirada e contato."
            }
            ```

6.  **Inicie o servidor:**
    ```bash
    npm run dev
    ```
    O servidor estará rodando em: `http://localhost:3000`

### 2. Configurar o Frontend

1.  **Abra o arquivo `frontend-adapted.html`** no seu navegador.
    *   Recomendado: Use um servidor local para evitar problemas de CORS e carregamento de arquivos.
    ```bash
    # Na pasta edu-imports-adapted/
    python3 -m http.server 8080
    # Acesse: http://localhost:8080/frontend-adapted.html
    ```

## 📝 Teste das Novas Funcionalidades

1.  **Teste de Cliente:**
    *   Cadastre um novo usuário ou faça login como `joao@email.com` / `123456`.
    *   Clique em "Comprar" em um produto.
    *   Verifique se o clique foi registrado (o WhatsApp será aberto).

2.  **Teste de Administrador:**
    *   Faça login como ADM: `admin@eduimports.com` / `123456`.
    *   Acesse o Painel Admin.
    *   Na aba "Pedidos Pendentes", valide o pedido criado no passo anterior.
    *   Na aba "Relatórios", baixe os arquivos Excel e PDF e verifique se o pedido validado está incluído.
    *   Acesse a aba "Localização" e verifique se o mapa está exibindo o marcador no endereço fixo.

---
*Desenvolvido por Manus AI para Edu_Imports*
