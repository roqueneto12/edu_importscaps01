# 🛍️ Edu_Imports - Loja Online com WhatsApp

Um projeto fullstack para e-commerce com autenticação de usuários, gerenciamento de produtos por administradores e integração direta com WhatsApp para vendas.

## 🚀 Funcionalidades Implementadas

### 👤 **Sistema de Usuários**
- ✅ Cadastro de novos usuários
- ✅ Login/Logout com autenticação JWT
- ✅ Diferentes níveis de acesso (Admin/Usuário)
- ✅ Proteção de rotas sensíveis

### 💬 **Integração WhatsApp**
- ✅ Redirecionamento direto para WhatsApp ao clicar em "Comprar"
- ✅ Mensagem pré-formatada com nome do produto e preço
- ✅ Número da loja já configurado (71) 8236-2019

### 👨‍💼 **Painel Administrativo**
- ✅ Criar novos produtos
- ✅ Editar produtos existentes
- ✅ Excluir produtos
- ✅ Gerenciar estoque
- ✅ Definir produtos em destaque

### 🎨 **Interface do Usuário**
- ✅ Design responsivo e moderno
- ✅ Produtos em destaque
- ✅ Catálogo completo de produtos
- ✅ Modais para login/registro
- ✅ Rodapé com informações da loja
- ✅ Links para redes sociais

## 📁 Estrutura do Projeto

```
edu-imports-fullstack/
├── backend/                     # API Node.js/Express.js
│   ├── config/
│   │   └── database.js         # Configuração MongoDB
│   ├── controllers/
│   │   ├── authController.js   # Autenticação
│   │   └── productController.js # Produtos
│   ├── middleware/
│   │   ├── auth.js            # Middleware de autenticação
│   │   └── errorHandler.js    # Tratamento de erros
│   ├── models/
│   │   ├── User.js            # Modelo de usuário
│   │   └── Product.js         # Modelo de produto
│   ├── routes/
│   │   ├── auth.js            # Rotas de autenticação
│   │   └── products.js        # Rotas de produtos
│   ├── .env                   # Variáveis de ambiente
│   ├── package.json           # Dependências do backend
│   ├── server.js              # Servidor principal
│   └── seedDataWithUsers.js   # Dados de exemplo
├── frontend-whatsapp.html     # Frontend com integração WhatsApp
└── README-WHATSAPP.md         # Esta documentação
```

## 🛠️ Como Configurar e Rodar

### 1. **Configurar o Backend**

1. **Navegue até a pasta do backend:**
   ```bash
   cd backend
   ```

2. **Instale as dependências:**
   ```bash
   npm install
   ```

3. **Configure o banco de dados:**
   O projeto já está configurado para usar MongoDB Atlas com a string de conexão fornecida.

4. **Popule o banco com dados de exemplo:**
   ```bash
   npm run seed
   ```
   
   Isso criará:
   - **Admin:** admin@eduimports.com / 123456
   - **Usuários:** joao@email.com / 123456, maria@email.com / 123456
   - **Produtos:** 6 produtos de exemplo

5. **Inicie o servidor:**
   ```bash
   npm run dev
   ```
   
   O servidor estará rodando em: http://localhost:3000

### 2. **Configurar o Frontend**

1. **Abra o arquivo `frontend-whatsapp.html`** no seu navegador
2. **Ou sirva via servidor local** (recomendado):
   ```bash
   # Se você tem Python instalado:
   python -m http.server 8080
   
   # Ou se você tem Node.js:
   npx serve .
   ```

## 🔐 Credenciais de Teste

Após rodar `npm run seed`, você pode usar estas credenciais:

### 👨‍💼 **Administrador**
- **Email:** admin@eduimports.com
- **Senha:** 123456
- **Permissões:** Gerenciar produtos, ver painel admin

### 👤 **Usuários Normais**
- **Email:** joao@email.com ou maria@email.com
- **Senha:** 123456
- **Permissões:** Visualizar produtos e comprar via WhatsApp

## 📚 API Endpoints

### 🔐 **Autenticação**
```http
POST /api/auth/register    # Cadastrar usuário
POST /api/auth/login       # Fazer login
GET  /api/auth/me          # Obter usuário atual
POST /api/auth/logout      # Fazer logout
```

### 📦 **Produtos**
```http
GET    /api/products           # Listar produtos
GET    /api/products/featured  # Produtos em destaque
GET    /api/products/ranking   # Ranking de vendas
GET    /api/products/:id       # Obter produto específico
POST   /api/products           # Criar produto (Admin)
PUT    /api/products/:id       # Atualizar produto (Admin)
DELETE /api/products/:id       # Excluir produto (Admin)
```

## 🎯 Como Usar o Sistema

### **Para Clientes:**

1. **Navegue pelos produtos** na página inicial
2. **Clique em "💬 Comprar no WhatsApp"** em qualquer produto
3. **Será redirecionado para o WhatsApp** da loja com uma mensagem pré-formatada contendo:
   - Nome do produto
   - Preço
   - Quantidade (padrão: 1)
4. **Complete a compra** diretamente no WhatsApp com o vendedor

### **Para Administradores:**

1. **Faça login** com credenciais de admin
2. **Acesse o painel admin** clicando em "Admin" no menu
3. **Adicione novos produtos** preenchendo o formulário
4. **Edite produtos existentes** clicando em "Editar" na tabela
5. **Exclua produtos** clicando em "Excluir" (com confirmação)
6. **Marque produtos como destaque** usando o checkbox

## 💬 Configuração do WhatsApp

### **Número da Loja:**
- **WhatsApp:** (71) 8236-2019
- **Formato internacional:** +557182362019

### **Mensagem Padrão:**
Quando um cliente clica em "Comprar no WhatsApp", a seguinte mensagem é enviada:

```
Olá! Gostaria de comprar:

📦 *[Nome do Produto]*
💰 Preço: R$ [Preço]
📊 Quantidade: 1

Poderia me ajudar com mais informações?
```

### **Personalizar Mensagem:**
Para alterar a mensagem padrão, edite a função `generateWhatsAppLink()` no arquivo `frontend-whatsapp.html`:

```javascript
generateWhatsAppLink(product, quantity = 1) {
    const phoneNumber = '557182362019';
    const message = `Sua mensagem personalizada aqui...`;
    const encodedMessage = encodeURIComponent(message);
    return `https://wa.me/${phoneNumber}?text=${encodedMessage}`;
}
```

## 🔧 Tecnologias Utilizadas

### **Backend:**
- **Node.js** - Runtime JavaScript
- **Express.js** - Framework web
- **MongoDB Atlas** - Banco de dados na nuvem
- **Mongoose** - ODM para MongoDB
- **JWT** - Autenticação via tokens
- **bcryptjs** - Criptografia de senhas

### **Frontend:**
- **Vue.js 3** - Framework JavaScript reativo
- **Axios** - Cliente HTTP para API
- **CSS3** - Estilização avançada
- **HTML5** - Estrutura semântica

### **Integração:**
- **WhatsApp Business API** - Redirecionamento direto
- **URL Encoding** - Formatação de mensagens

## 🎨 Características Visuais

### **Design Responsivo:**
- ✅ Funciona em desktop, tablet e mobile
- ✅ Menu adaptativo para telas pequenas
- ✅ Cards de produtos responsivos

### **Cores e Estilo:**
- **Cor principal:** Dourado (#ffd700)
- **Fundo:** Imagem da marca Edu_Imports
- **Botão WhatsApp:** Verde WhatsApp (#25d366)
- **Cards:** Fundo escuro com bordas arredondadas

### **Animações:**
- ✅ Hover effects nos produtos
- ✅ Transições suaves
- ✅ Animação de pulse no banner

## 🚀 Funcionalidades Avançadas

### **Segurança:**
- ✅ Senhas criptografadas com bcrypt
- ✅ Autenticação JWT com expiração
- ✅ Proteção de rotas por role (admin/user)
- ✅ Validação de dados de entrada

### **Performance:**
- ✅ Índices no banco de dados
- ✅ Lazy loading de dados
- ✅ Cache de autenticação

### **UX/UI:**
- ✅ Feedback visual (alertas, loading)
- ✅ Modais para ações importantes
- ✅ Redirecionamento direto para WhatsApp

## 🐛 Solução de Problemas

### **Backend não inicia:**
```bash
# Verificar se o MongoDB Atlas está acessível
npm run dev

# Verificar logs do servidor
```

### **Frontend não conecta com API:**
- Verifique se o backend está rodando na porta 3000
- Confirme que não há bloqueio de CORS
- Abra o console do navegador para ver erros

### **WhatsApp não abre:**
- Verifique se o número está correto: 557182362019
- Confirme que o WhatsApp está instalado no dispositivo
- Em desktop, pode abrir o WhatsApp Web

## 📈 Próximas Funcionalidades

- [ ] **Sistema de Cupons de Desconto**
- [ ] **Catálogo em PDF para WhatsApp**
- [ ] **Integração com WhatsApp Business API**
- [ ] **Sistema de Avaliações**
- [ ] **Busca Avançada** com filtros
- [ ] **Dashboard de Vendas**
- [ ] **Notificações por Email**

## 🤝 Para Desenvolvedores

### **Estrutura Simplificada:**
- Removido sistema de carrinho complexo
- Foco na integração direta com WhatsApp
- Interface limpa e objetiva

### **Vantagens da Integração WhatsApp:**
1. **Conversão direta:** Cliente vai direto para o vendedor
2. **Personalização:** Atendimento humanizado
3. **Confiança:** Cliente vê que é uma pessoa real
4. **Flexibilidade:** Negociação de preços e condições
5. **Simplicidade:** Não precisa de gateway de pagamento

### **Comandos Úteis:**

```bash
# Instalar dependências
npm install

# Rodar em desenvolvimento
npm run dev

# Popular banco de dados
npm run seed

# Testar API
curl -X GET http://localhost:3000/api/products
```

## 📞 Contato da Loja

- **WhatsApp:** (71) 8236-2019
- **Instagram:** @edu_.importss
- **Email:** contato@eduimports.com
- **Localização:** Salvador, Bahia - Brasil

---

**Desenvolvido para Edu_Imports** 🛍️

*Este projeto demonstra um e-commerce moderno com integração direta ao WhatsApp, ideal para vendas personalizadas e atendimento humanizado.*

