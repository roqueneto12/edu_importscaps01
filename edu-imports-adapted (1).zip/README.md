# Projeto Edu_Imports Fullstack

Este projeto contém o frontend (HTML/CSS/Vue.js) e o backend (Node.js/Express.js/MongoDB) para a loja Edu_Imports.

## 🚀 Como Rodar o Projeto

Para colocar este projeto para funcionar, siga os passos abaixo:

### 1. Configurar o Backend (API)

O backend é a parte que lida com os dados (produtos, etc.) e se comunica com o banco de dados.

**Passo a passo:**

1.  **Abra o terminal** e navegue até a pasta `backend`:
    ```bash
    cd backend
    ```

2.  **Instale as dependências** (bibliotecas que o projeto precisa):
    ```bash
    npm install
    ```

3.  **Configure o banco de dados (MongoDB)**:
    *   **Opção mais fácil (Docker):** Se você tem Docker instalado, rode este comando no terminal:
        ```bash
        docker run -d -p 27017:27017 --name mongodb mongo
        ```
        Isso vai iniciar um servidor MongoDB em seu computador.
    *   **Opção local:** Você pode instalar o MongoDB diretamente em seu computador. Pesquise por "instalar MongoDB" para o seu sistema operacional.
    *   **Opção na nuvem (MongoDB Atlas):** Para um projeto mais sério, você pode usar o MongoDB Atlas (gratuito para começar). Crie uma conta, crie um cluster e pegue a "string de conexão".

4.  **Crie um arquivo de configurações**:
    *   Na pasta `backend`, você verá um arquivo chamado `.env.example`. Copie-o e renomeie a cópia para `.env`.
    *   Abra o arquivo `.env` e, se estiver usando MongoDB Atlas, cole sua string de conexão na linha `MONGODB_URI=`.

5.  **Popule o banco de dados com dados de exemplo** (opcional, mas recomendado para testar):
    ```bash
    npm run seed
    ```

6.  **Inicie o servidor backend**:
    ```bash
    npm run dev
    ```
    Se tudo der certo, você verá uma mensagem no terminal dizendo que o servidor está rodando na porta `3000`.

### 2. Configurar o Frontend (Interface do Usuário)

O frontend é o arquivo HTML que você abriu no navegador. Ele vai se comunicar com o backend que você acabou de iniciar.

**Passo a passo:**

1.  **Abra o arquivo `frontend.html`** no seu navegador de internet (Chrome, Firefox, etc.). Você pode simplesmente arrastar o arquivo para a janela do navegador ou clicar duas vezes nele.

2.  **Verifique a integração:**
    *   O frontend está configurado para buscar dados do backend na URL `http://localhost:3000/api`. Certifique-se de que o backend esteja rodando na porta 3000.
    *   Você pode precisar fazer pequenas modificações no `frontend.html` para que ele faça requisições para a API. Por exemplo, onde ele busca imagens ou dados estáticos, você precisará adaptá-lo para buscar da sua API.

## 📂 Estrutura do Projeto

```
edu-imports-fullstack/
├── backend/                 # Pasta com o código do servidor (Node.js/Express.js)
│   ├── config/              # Configurações (ex: conexão com banco de dados)
│   ├── controllers/         # Lógica de como a API responde às requisições
│   ├── middleware/          # Funções que rodam antes das requisições chegarem aos controllers
│   ├── models/              # Como os dados são estruturados no banco de dados
│   ├── routes/              # Endereços (URLs) da sua API
│   ├── .env.example         # Exemplo de arquivo de configurações
│   ├── package.json         # Lista de dependências e scripts do backend
│   ├── seedData.js          # Script para adicionar dados de exemplo ao banco
│   └── server.js            # O arquivo principal que inicia o servidor
├── frontend.html            # O arquivo HTML original do frontend
└── README.md                # Este arquivo de instruções
```

## 💡 Dicas para Desenvolvedores Júnior

*   **Terminal:** Acostume-se a usar o terminal (linha de comando). É uma ferramenta poderosa!
*   **`npm install`:** Sempre que você baixar um projeto Node.js, o primeiro passo é rodar `npm install` para baixar as dependências.
*   **`.env`:** Nunca envie o arquivo `.env` para o GitHub ou outros repositórios públicos! Ele contém informações sensíveis (senhas, chaves de API). Use sempre o `.env.example` para mostrar quais variáveis são necessárias.
*   **`localhost`:** `localhost` significa "seu próprio computador". `http://localhost:3000` significa que o servidor está rodando na porta 3000 do seu computador.
*   **Testando a API:** Você pode usar ferramentas como o [Postman](https://www.postman.com/downloads/) ou [Insomnia](https://insomnia.rest/download) para testar os endpoints da API sem precisar do frontend.

---

